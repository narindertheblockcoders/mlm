"use strict";
/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "pages/api/auth/[...nextauth]";
exports.ids = ["pages/api/auth/[...nextauth]"];
exports.modules = {

/***/ "axios":
/*!************************!*\
  !*** external "axios" ***!
  \************************/
/***/ ((module) => {

module.exports = require("axios");

/***/ }),

/***/ "next-auth":
/*!****************************!*\
  !*** external "next-auth" ***!
  \****************************/
/***/ ((module) => {

module.exports = require("next-auth");

/***/ }),

/***/ "next-auth/providers/credentials":
/*!**************************************************!*\
  !*** external "next-auth/providers/credentials" ***!
  \**************************************************/
/***/ ((module) => {

module.exports = require("next-auth/providers/credentials");

/***/ }),

/***/ "(api)/./pages/api/auth/[...nextauth].js":
/*!*****************************************!*\
  !*** ./pages/api/auth/[...nextauth].js ***!
  \*****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (__WEBPACK_DEFAULT_EXPORT__)\n/* harmony export */ });\n/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! axios */ \"axios\");\n/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var next_auth__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! next-auth */ \"next-auth\");\n/* harmony import */ var next_auth__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_auth__WEBPACK_IMPORTED_MODULE_1__);\n/* harmony import */ var next_auth_providers_credentials__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! next-auth/providers/credentials */ \"next-auth/providers/credentials\");\n/* harmony import */ var next_auth_providers_credentials__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_auth_providers_credentials__WEBPACK_IMPORTED_MODULE_2__);\n\n\n\n/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (next_auth__WEBPACK_IMPORTED_MODULE_1___default()({\n    session: {\n        strategy: \"jwt\",\n        maxAge: 1500,\n        secret: \"ayC5ej+5fmSNxGt61XXH2uSa61wQgCr2dUwmAoDUzXs=\"\n    },\n    providers: [\n        next_auth_providers_credentials__WEBPACK_IMPORTED_MODULE_2___default()({\n            name: \"Custom Provider\",\n            async authorize (credentials) {\n                let { email , password  } = credentials;\n                console.log(credentials, \"for credentials\");\n                let data = {\n                    email: email,\n                    password: password\n                };\n                console.log(data, \"form email and password\");\n                let response = await axios__WEBPACK_IMPORTED_MODULE_0___default().post(\"http://192.168.1.48:2000/api/v1/auth/userLogIn\", data);\n                console.log(response, \"response\");\n                let user = response.data;\n                // console.log(user, \"data for user\")\n                let token = response.data.data;\n                // console.log(token, 'for token')\n                if (!token) {\n                    throw new Error(\"Invalid token\");\n                }\n                if (!(response.status == 200)) {\n                    throw new Error(\"Invalid Credentials\" + email);\n                }\n                if (response.status == 200) {\n                    return user = {\n                        name: token,\n                        email: email\n                    };\n                }\n            }\n        }), \n    ]\n}));\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKGFwaSkvLi9wYWdlcy9hcGkvYXV0aC9bLi4ubmV4dGF1dGhdLmpzLmpzIiwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7QUFBMEI7QUFDTztBQUNrQztBQUVuRSxpRUFBZUMsZ0RBQVEsQ0FBQztJQUN0QkUsT0FBTyxFQUFFO1FBQ1BDLFFBQVEsRUFBRSxLQUFLO1FBQ2ZDLE1BQU0sRUFBRSxJQUFJO1FBQ1pDLE1BQU0sRUFBRSw4Q0FBOEM7S0FDdkQ7SUFDREMsU0FBUyxFQUFFO1FBQ1RMLHNFQUFvQixDQUFDO1lBQ25CTSxJQUFJLEVBQUUsaUJBQWlCO1lBQ3ZCLE1BQU1DLFNBQVMsRUFBQ0MsV0FBVyxFQUFFO2dCQUMzQixJQUFJLEVBQUVDLEtBQUssR0FBRUMsUUFBUSxHQUFFLEdBQUdGLFdBQVc7Z0JBQ3JDRyxPQUFPLENBQUNDLEdBQUcsQ0FBQ0osV0FBVyxFQUFFLGlCQUFpQixDQUFDLENBQUM7Z0JBQzVDLElBQUlLLElBQUksR0FBRztvQkFBRUosS0FBSyxFQUFFQSxLQUFLO29CQUFFQyxRQUFRLEVBQUVBLFFBQVE7aUJBQUU7Z0JBQy9DQyxPQUFPLENBQUNDLEdBQUcsQ0FBQ0MsSUFBSSxFQUFFLHlCQUF5QixDQUFDLENBQUM7Z0JBQzdDLElBQUlDLFFBQVEsR0FBRyxNQUFNaEIsaURBQVUsQ0FDN0IsZ0RBQWdELEVBQ2hEZSxJQUFJLENBQ0w7Z0JBQ0RGLE9BQU8sQ0FBQ0MsR0FBRyxDQUFDRSxRQUFRLEVBQUUsVUFBVSxDQUFDLENBQUM7Z0JBQ2xDLElBQUlFLElBQUksR0FBR0YsUUFBUSxDQUFDRCxJQUFJO2dCQUN4QixxQ0FBcUM7Z0JBQ3JDLElBQUlJLEtBQUssR0FBR0gsUUFBUSxDQUFDRCxJQUFJLENBQUNBLElBQUk7Z0JBQzlCLGtDQUFrQztnQkFFbEMsSUFBSSxDQUFDSSxLQUFLLEVBQUU7b0JBQ1YsTUFBTSxJQUFJQyxLQUFLLENBQUMsZUFBZSxDQUFDLENBQUM7aUJBQ2xDO2dCQUNELElBQUksQ0FBQyxDQUFDSixRQUFRLENBQUNLLE1BQU0sSUFBSSxHQUFHLENBQUMsRUFBRTtvQkFDN0IsTUFBTSxJQUFJRCxLQUFLLENBQUMscUJBQXFCLEdBQUdULEtBQUssQ0FBQyxDQUFDO2lCQUNoRDtnQkFDRCxJQUFJSyxRQUFRLENBQUNLLE1BQU0sSUFBSSxHQUFHLEVBQUU7b0JBQzFCLE9BQVFILElBQUksR0FBRzt3QkFDYlYsSUFBSSxFQUFFVyxLQUFLO3dCQUNYUixLQUFLLEVBQUVBLEtBQUs7cUJBQ2IsQ0FBRTtpQkFDSjthQUNGO1NBQ0YsQ0FBQztLQUNIO0NBQ0YsQ0FBQyxFQUFDIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vaGVhbHRoaS8uL3BhZ2VzL2FwaS9hdXRoL1suLi5uZXh0YXV0aF0uanM/NTI3ZiJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgYXhpb3MgZnJvbSBcImF4aW9zXCI7XG5pbXBvcnQgTmV4dEF1dGggZnJvbSBcIm5leHQtYXV0aFwiO1xuaW1wb3J0IENyZWRlbnRpYWxzUHJvdmlkZXJzIGZyb20gXCJuZXh0LWF1dGgvcHJvdmlkZXJzL2NyZWRlbnRpYWxzXCI7XG5cbmV4cG9ydCBkZWZhdWx0IE5leHRBdXRoKHtcbiAgc2Vzc2lvbjoge1xuICAgIHN0cmF0ZWd5OiBcImp3dFwiLFxuICAgIG1heEFnZTogMTUwMCxcbiAgICBzZWNyZXQ6IFwiYXlDNWVqKzVmbVNOeEd0NjFYWEgydVNhNjF3UWdDcjJkVXdtQW9EVXpYcz1cIixcbiAgfSxcbiAgcHJvdmlkZXJzOiBbXG4gICAgQ3JlZGVudGlhbHNQcm92aWRlcnMoe1xuICAgICAgbmFtZTogXCJDdXN0b20gUHJvdmlkZXJcIixcbiAgICAgIGFzeW5jIGF1dGhvcml6ZShjcmVkZW50aWFscykge1xuICAgICAgICBsZXQgeyBlbWFpbCwgcGFzc3dvcmQgfSA9IGNyZWRlbnRpYWxzO1xuICAgICAgICBjb25zb2xlLmxvZyhjcmVkZW50aWFscywgXCJmb3IgY3JlZGVudGlhbHNcIik7XG4gICAgICAgIGxldCBkYXRhID0geyBlbWFpbDogZW1haWwsIHBhc3N3b3JkOiBwYXNzd29yZCB9O1xuICAgICAgICBjb25zb2xlLmxvZyhkYXRhLCBcImZvcm0gZW1haWwgYW5kIHBhc3N3b3JkXCIpO1xuICAgICAgICBsZXQgcmVzcG9uc2UgPSBhd2FpdCBheGlvcy5wb3N0KFxuICAgICAgICAgIFwiaHR0cDovLzE5Mi4xNjguMS40ODoyMDAwL2FwaS92MS9hdXRoL3VzZXJMb2dJblwiLFxuICAgICAgICAgIGRhdGFcbiAgICAgICAgKTtcbiAgICAgICAgY29uc29sZS5sb2cocmVzcG9uc2UsIFwicmVzcG9uc2VcIik7XG4gICAgICAgIGxldCB1c2VyID0gcmVzcG9uc2UuZGF0YTtcbiAgICAgICAgLy8gY29uc29sZS5sb2codXNlciwgXCJkYXRhIGZvciB1c2VyXCIpXG4gICAgICAgIGxldCB0b2tlbiA9IHJlc3BvbnNlLmRhdGEuZGF0YTtcbiAgICAgICAgLy8gY29uc29sZS5sb2codG9rZW4sICdmb3IgdG9rZW4nKVxuXG4gICAgICAgIGlmICghdG9rZW4pIHtcbiAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoXCJJbnZhbGlkIHRva2VuXCIpO1xuICAgICAgICB9XG4gICAgICAgIGlmICghKHJlc3BvbnNlLnN0YXR1cyA9PSAyMDApKSB7XG4gICAgICAgICAgdGhyb3cgbmV3IEVycm9yKFwiSW52YWxpZCBDcmVkZW50aWFsc1wiICsgZW1haWwpO1xuICAgICAgICB9XG4gICAgICAgIGlmIChyZXNwb25zZS5zdGF0dXMgPT0gMjAwKSB7XG4gICAgICAgICAgcmV0dXJuICh1c2VyID0ge1xuICAgICAgICAgICAgbmFtZTogdG9rZW4sXG4gICAgICAgICAgICBlbWFpbDogZW1haWwsXG4gICAgICAgICAgfSk7XG4gICAgICAgIH1cbiAgICAgIH0sXG4gICAgfSksXG4gIF0sXG59KTtcbiJdLCJuYW1lcyI6WyJheGlvcyIsIk5leHRBdXRoIiwiQ3JlZGVudGlhbHNQcm92aWRlcnMiLCJzZXNzaW9uIiwic3RyYXRlZ3kiLCJtYXhBZ2UiLCJzZWNyZXQiLCJwcm92aWRlcnMiLCJuYW1lIiwiYXV0aG9yaXplIiwiY3JlZGVudGlhbHMiLCJlbWFpbCIsInBhc3N3b3JkIiwiY29uc29sZSIsImxvZyIsImRhdGEiLCJyZXNwb25zZSIsInBvc3QiLCJ1c2VyIiwidG9rZW4iLCJFcnJvciIsInN0YXR1cyJdLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///(api)/./pages/api/auth/[...nextauth].js\n");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__("(api)/./pages/api/auth/[...nextauth].js"));
module.exports = __webpack_exports__;

})();